package com.example.Webproj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebprojApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebprojApplication.class, args);
	}

}
